Bot Version = 1.5

IMPORTANT
Recommended - Create and alt, get it's user id
Recommended - Use developer mode to get the stuff
Support server - https://discord.gg/sfrWPmbXAu

INSTRUCTIONS
- Do this on a seperate server where you, your alt and dank memer stay
- Don't talk about this dank memer tool or else youre going to get banned from dank memer
- Install python 3.7+ with path (3.9 should work fine)
- do "py -3.9 -m pip install discord.py[voice] --extra-index-url https://gorialis.github.io/pip/" in cmd
- fill out everything in config.py
- Run this file (F5 or just click on it)

RULES
- Fill the stuff out below
- Don't touch the code
- Report all errors to the owner
- This is the beta version
- Enjoy the Stuff

CAUTION 
- Against discord and Dank Memer TOS (ILLEGAL)