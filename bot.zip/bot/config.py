#hold alt then press 454
prefix = '╞'

#channel you want to log everything in
logs = int('')

#server that you are using to do this
server_id = int('')

#The id of the account youre using
user_id = int('')

#user token for the account youre using (inspect => network =>  headings => authorization)
token = ''